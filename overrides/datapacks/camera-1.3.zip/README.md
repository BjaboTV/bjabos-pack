# camera
> `/trigger camera` command to swap b/w spectator and survival modes

Designed for the hermitcraft camera accounts used for footage.

## Usage

`/trigger camera` to swap between spectator and survival!

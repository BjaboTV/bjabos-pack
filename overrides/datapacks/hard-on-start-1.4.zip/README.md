# hard-on-start

Simply sets the game to hard when the server starts (and restarts).

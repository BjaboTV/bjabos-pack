# tp-tools
> Provides helpful quick tp commands for spectators to get around easily

## Usage

Running `/trigger tptools` in spectator mode will launch a teleport menu in-chat for easily getting around. These buttons will only work if you are in spectator mode.

![Screenshot of tp-tools](imgs/in-game.png)

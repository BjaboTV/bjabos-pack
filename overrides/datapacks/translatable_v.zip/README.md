# translatable
 This datapack allows you to set translatable text to items in survival.
 Use /trigger translatableName set <value> to set the value for the translatable text.
 

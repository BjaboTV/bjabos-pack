# Redstone Tweaks UI Changes (Multi-language)

Add additional language support for Redstone Tweaks UI Changes, not just English.
